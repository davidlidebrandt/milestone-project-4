$(document).ready(function () { 
        console.log("hello")
        let val = $("#product-quantity-input").val()
        console.log(val)
        if (val === 1) {
            $("#active-minus-button").hide()
        }
    
});
console.log("helloooo")